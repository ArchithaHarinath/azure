Name: Harsha Keerthipati
Id: 1001374263

Programming Language: Java

Run the code:

1) javac dtree.java

2) java dtree pendigits_training.txt pendigits_test.txt optimized 3

References:

http://scikit-learn.org/stable/modules/tree.html

https://medium.com/machine-learning-101/chapter-3-decision-trees-theory-e7398adac567

https://github.com/Kunwardev/Decision-Tree/blob/master/dtree.java

https://github.com/ErikGartner/dTree