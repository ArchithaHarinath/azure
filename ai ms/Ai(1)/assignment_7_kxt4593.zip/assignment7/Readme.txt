
Kevin Thomas
1001544593
                                            Assignment-7
                              

Problem1. 
1]First 8 lines of Hanoi_fact file is common to every problem, also first 10 lines of precondition is common to every problem.
2]First 18 lines of Puzzle_fact file is common to every problem
3]First 24 lines of Puzzle_fact file preconditions is common to every problem.

Solution.pdf contains solutions to all the remaining problems.
